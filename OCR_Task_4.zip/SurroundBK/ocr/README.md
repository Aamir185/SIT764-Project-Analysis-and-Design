# ocr

Surround Pipeline for OCR

# Run project
`surround run`
