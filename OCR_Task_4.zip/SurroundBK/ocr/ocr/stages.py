from surround import Estimator, SurroundData, Validator
import cv2
import pytesseract


class OcrData(SurroundData):
    input_data = None
    output_data = None


class ValidateData(Validator):
    def validate(self, surround_data, config):
        if not surround_data.input_data:
            raise ValueError("'input_data' is None")


class performOCR(Estimator):
    def estimate(self, surround_data, config):
        imPath = surround_data.input_data
        c = '-l eng --oem 1 --psm 3'
        im = cv2.imread(imPath, cv2.IMREAD_COLOR)
        surround_data.output_data = pytesseract.image_to_string(im, config=c)

    def fit(self, surround_data, config):
        print("TODO: Train your model here")
