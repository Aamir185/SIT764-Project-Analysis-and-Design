import logging
from surround import Runner
from stages import OcrData
import tkinter
from PIL import Image, ImageTk
import xlsxwriter as xl
from tkinter import filedialog
import re
import os

logging.basicConfig(level=logging.INFO)


class BatchRunner(Runner):

    def run(self, is_training=False):
        self.assembler.init_assembler(True)
        data = OcrData()
        root = tkinter.Tk()
        # root.withdraw()

        file_name = "ocr_output.xlsx"
        wb = xl.Workbook(file_name)
        ws = wb.add_worksheet("Output")

        def open_dialog():
            path = filedialog.askopenfilenames(parent=root, title="Choose an image")
            row = 0
            col = 0

            for i in path:
                # pathvar.set(path)
                data.input_data = i

                # im = Image.open(data.input_data)
                # selImage = ImageTk.PhotoImage(im)
                # var = tkinter.Label(root, image=selImage)
                # var.image = selImage
                # var.pack()

                self.assembler.run(data, is_training)

                r1 = r1 = r".*Total\D*\$*(\d+\.*\d+)"
                bill_amount = re.findall(r1, data.output_data)
                if len(bill_amount) != 0:
                    output = bill_amount[0]
                else:
                    output = "Couldn't extract bill"

                ws.write(row, col, output)
                row += 1

            output_label = tkinter.StringVar()
            label = tkinter.Label(root, textvariable=output_label)
            output_label.set("Output Location: " + os.getcwd() + "\\" + file_name)
            label.pack()
            wb.close()

        # pathvar = tkinter.StringVar()
        browseBtn = tkinter.Button(root, text="Browse for Images", command=open_dialog)
        # print(pathvar)
        # data.input_data = pathvar

        browseBtn.pack()

        txt_label = tkinter.StringVar()
        label = tkinter.Label(root, textvariable=txt_label)
        txt_label.set("Your selected image: ")
        label.pack()

        root.mainloop()



        # Load data to be processed
        # raw_data = "data/ocr_test2.png"
        # raw_data = filedialog.askopenfilenames(parent=root, title="Choose an image")
        # Setup input data

        # data.input_data = raw_data
        # Run assembler




        # logging.info("Output: ")
        # print(data.output_data+"\n")
