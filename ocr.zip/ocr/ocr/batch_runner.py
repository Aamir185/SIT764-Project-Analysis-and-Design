import logging
from surround import Runner
from stages import OcrData
import tkinter
from tkinter import filedialog

logging.basicConfig(level=logging.INFO)


class BatchRunner(Runner):
    def run(self, is_training=False):
        self.assembler.init_assembler(True)
        data = OcrData()

        root = tkinter.Tk()
        root.withdraw()

        # Load data to be processed
        # raw_data = "data/ocr_test2.png"
        raw_data = filedialog.askopenfilenames(parent=root, title="Choose an image")
        # Setup input data

        for image in raw_data:
            data.input_data = image
            # Run assembler
            self.assembler.run(data, is_training)
            logging.info("Output: ")
            print(data.output_data+"\n")
